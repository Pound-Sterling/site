<?php
/* Smarty version 3.1.39, created on 2021-07-29 18:03:31
  from 'Z:\home\Site\views\default\footer.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.39',
  'unifunc' => 'content_6102df633058a3_32854380',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'dfe3222e781e86d27e2a21de86fed9cd9943f319' => 
    array (
      0 => 'Z:\\home\\Site\\views\\default\\footer.tpl',
      1 => 1627578203,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_6102df633058a3_32854380 (Smarty_Internal_Template $_smarty_tpl) {
?>                </div>
            </div>
        </div>
    </main>
    <div id="footer">
        <div>
            f
        </div>
    </div>
    
<?php echo '<script'; ?>
 src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 src="/js/style.js"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 src="/js/main.js"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 src="/js/burger.js"><?php echo '</script'; ?>
>
</body>

</html><?php }
}
