<?php
/* Smarty version 3.1.39, created on 2021-08-02 10:16:46
  from 'C:\OpenServer\domains\site\views\admin\adminLeftcolumn.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.39',
  'unifunc' => 'content_61079bde960871_60849652',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '015a9e8ae9053a81e0a8b42b1541fea351738ef5' => 
    array (
      0 => 'C:\\OpenServer\\domains\\site\\views\\admin\\adminLeftcolumn.tpl',
      1 => 1627888605,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_61079bde960871_60849652 (Smarty_Internal_Template $_smarty_tpl) {
?><div id="leftColumn">

<div id="leftMenu">
    <div class="menuCaption">Меню:</div>
    <a href="/admin/">Главная</a><br>
    <a href="/admin/category/">Категории</a><br>
    <a href="/admin/products/">Товар</a><br>
    <a href="/admin/orders/">Заказы</a>
</div>

</div><?php }
}
