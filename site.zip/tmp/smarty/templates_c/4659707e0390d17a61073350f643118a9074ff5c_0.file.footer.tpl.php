<?php
/* Smarty version 3.1.39, created on 2021-08-14 20:31:27
  from 'C:\OpenServer\domains\site\views\default\footer.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.39',
  'unifunc' => 'content_6117fdef89b708_23687471',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '4659707e0390d17a61073350f643118a9074ff5c' => 
    array (
      0 => 'C:\\OpenServer\\domains\\site\\views\\default\\footer.tpl',
      1 => 1628962286,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:popup.tpl' => 1,
  ),
),false)) {
function content_6117fdef89b708_23687471 (Smarty_Internal_Template $_smarty_tpl) {
?></div>
</div>
</main>
<div id="footer">
    <div>
        f
    </div>
</div>

<?php $_smarty_tpl->_subTemplateRender('file:popup.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

<?php echo '<script'; ?>
 src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 src="/js/style.js"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 src="/js/main.js"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 src="/js/slider.js"><?php echo '</script'; ?>
>
</body>

</html><?php }
}
