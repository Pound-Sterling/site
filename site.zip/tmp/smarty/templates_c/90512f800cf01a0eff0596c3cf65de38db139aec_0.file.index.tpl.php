<?php
/* Smarty version 3.1.39, created on 2021-07-28 12:18:41
  from 'Z:\home\Site\views\default\index.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.39',
  'unifunc' => 'content_61013d117538f6_53029334',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '90512f800cf01a0eff0596c3cf65de38db139aec' => 
    array (
      0 => 'Z:\\home\\Site\\views\\default\\index.tpl',
      1 => 1627471083,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_61013d117538f6_53029334 (Smarty_Internal_Template $_smarty_tpl) {
?><div class="index">
123123123
</div><?php }
}
