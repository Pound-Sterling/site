<?php
/* Smarty version 3.1.39, created on 2021-08-03 20:55:57
  from 'C:\OpenServer\domains\site\views\admin\adminFooter.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.39',
  'unifunc' => 'content_6109832d2c5557_10981800',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'ec242b5a0ee8c67797b9b842745594e3131e443e' => 
    array (
      0 => 'C:\\OpenServer\\domains\\site\\views\\admin\\adminFooter.tpl',
      1 => 1627916554,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_6109832d2c5557_10981800 (Smarty_Internal_Template $_smarty_tpl) {
?>

    </div>
    <div id="footer">
        Footer
        Footer
        Footer
    </div>
<?php echo '<script'; ?>
 src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 src="<?php echo $_smarty_tpl->tpl_vars['templateWebPath']->value;?>
/js/admin.js"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 src="<?php echo $_smarty_tpl->tpl_vars['templateWebPath']->value;?>
/js/style.js"><?php echo '</script'; ?>
>
</body>

</html><?php }
}
