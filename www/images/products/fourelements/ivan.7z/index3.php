<? include_once 'header.php';?>
<header></header>
<main>
    <aside>
        <? include_once 'nav.php';?>

    </aside>
    <section>
        <div class="padding">
            <form action="/form" method="POST">
                <p><input type="text" name="login" placeholder="Login"></p>
                <p><input type="password" name="password" placeholder="Password"></p>
                <p><input type="submit" name="enter" value="Submit"></p>
                <div class="g-recaptcha" data-sitekey="your_site_key"></div>

            </form>
        </div>
    </section>
</main>
<? include_once 'footer.php';?>