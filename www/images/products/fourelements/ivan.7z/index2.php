<? include_once 'header.php';?>
<header></header>
<main>
    <aside>
        <? include_once 'nav.php';?>

    </aside>
    <section>
    <div class="box">
        <div class="item"></div>
        <div class="item"></div>
        <div class="item"></div>
        <div class="item"></div>
        <div class="item"></div>
        <div class="item"></div>

    </div>
    </section>
</main>
<? include_once 'footer.php';?>
