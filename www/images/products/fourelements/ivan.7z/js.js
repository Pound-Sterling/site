var slideIndex = 1;
function plusSlides(n) {
    console.log(slideIndex);
    showSlides(slideIndex += n);
}
function currentSlide(n) {
    showSlides(slideIndex = n);
}

function showSlides(s) {
    var i;
    var slides = document.getElementsByClassName("mySlides");
    console.log(slides.length + ' slides length');
    var dots = document.getElementsByClassName("dot");
    console.log(slideIndex + ' index before');
    if (s > slides.length) {
        slideIndex = 1;
        console.log("> legth");
    }
    if (s < 1) {
        slideIndex = slides.length;
        console.log("< 1");

    }
    for (i = 0; i < slides.length; i++) {
        slides[i].style.display = "none";
    }
    for (i = 0; i < dots.length; i++) {
        dots[i].className = dots[i].className.replace("active", "");
    }
    console.log(slideIndex + ' index after');
    console.log(' ------------------ ');
    slides[slideIndex - 1].style.display = "block";
    dots[slideIndex - 1].className += " active";
}