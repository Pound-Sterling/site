<a href="index.php">html1</a>
<a href="index2.php">html2</a>
<a href="index3.php">html3</a>
