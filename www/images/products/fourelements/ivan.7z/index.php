


<? include_once 'header.php'; ?>
<header></header>
<main>
    <aside>
        <? include_once 'nav.php';?>

    </aside>
    <section>
    <div class="product-page__img-wrappers" bis_skin_checked="1">
        <div class="slider-container" bis_skin_checked="1">
            <div class="slider-track" bis_skin_checked="1">

                <div class="mySlides fade" style="display: block;" bis_skin_checked="1">
                    <img class="product-page__img_0" style="width: 100%;" src="images/image-1-700x1000.jpg">
                </div>
                <div class="mySlides fade" style="display: none;" bis_skin_checked="1">
                    <img class="product-page__img_1" style="width: 100%;" src="images/image-2-700x1000.jpg">
                </div>
                <div class="mySlides fade" style="display: none;" bis_skin_checked="1">
                    <img class="product-page__img_2" style="width: 100%;" src="images/image-3-700x1000.jpg">
                </div>
                <div class="mySlides fade" style="display: none;" bis_skin_checked="1">
                    <img class="product-page__img_3" style="width: 100%;" src="images/image-4-700x1000.jpg">
                </div>
                <div class=" mySlides fade" style="display: none;" bis_skin_checked="1">
                    <img class="product-page__img_4" style="width: 100%;" src="images/image-5-700x1000.jpg">
                </div>
                <div class="mySlides fade" style="display: none;" bis_skin_checked="1">
                    <img class="product-page__img_5" style="width: 100%;" src="images/image-6-700x1000.jpg">
                </div>
                <div class="mySlides fade" style="display: none;" bis_skin_checked="1">
                    <img class="product-page__img_6" style="width: 100%;" src="images/image-7-700x1000.jpg">
                </div>
                <div class="mySlides fade" style="display: none;" bis_skin_checked="1">
                    <img class="product-page__img_6" style="width: 100%;" src="images/image-8-700x1000.jpg">
                </div>
            </div>
            <div class="dots" bis_skin_checked="1">
                <div class="dot active" onclick="currentSlide(1)" bis_skin_checked="1"></div>
                <div class="dot" onclick="currentSlide(2)" bis_skin_checked="1"></div>
                <div class="dot" onclick="currentSlide(3)" bis_skin_checked="1"></div>
                <div class="dot" onclick="currentSlide(4)" bis_skin_checked="1"></div>
                <div class="dot" onclick="currentSlide(5)" bis_skin_checked="1"></div>
                <div class="dot" onclick="currentSlide(6)" bis_skin_checked="1"></div>
                <div class="dot" onclick="currentSlide(7)" bis_skin_checked="1"></div>
                <div class="dot" onclick="currentSlide(8)" bis_skin_checked="1"></div>
            </div>
        </div>
        <div class="slider-buttons" bis_skin_checked="1">
            <button class="btn-prev" onclick="plusSlides(-1)">Prev</button>
            <button class="btn-next" onclick="plusSlides(1)">Next</button>
        </div>
    </div>
    </section>
</main>
<? include_once 'footer.php';?>